function res = SetDelayed(varargin)
% shortcut form for exp_setdelayed()
res = exp_setdelayed(varargin{:});