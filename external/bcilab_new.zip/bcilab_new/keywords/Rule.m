function res = Rule(varargin)
% shortcut form for exp_rule()
res = exp_rule(varargin{:});