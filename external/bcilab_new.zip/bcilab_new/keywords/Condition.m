function res = Condition(varargin)
% shortcut form for exp_condition()
res = exp_condition(varargin{:});